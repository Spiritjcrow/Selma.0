package sol.selma.audiomatrix;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Process;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Microphone capture, mono 16-bit PCM, capped for lower-RAM Android phones. */
public final class AudioRecorder {
    public interface Listener {
        void onLevel(float[] lastSamples, int seconds);
        void onFinished(float[] samples, int sampleRate, String problem);
    }
    public static final int RATE=48000;
    public static final int FALLBACK_RATE=44100;
    public static final int MAX_SECONDS=120;
    private final AtomicBoolean recording=new AtomicBoolean(false);
    private AudioRecord current;
    private Thread worker;

    public boolean isRecording() {return recording.get();}
    @SuppressWarnings("MissingPermission")
    public void start(Listener listener) {
        if(!recording.compareAndSet(false,true)) return;
        worker=new Thread(()->{
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            AudioRecord rec=null;
            ByteArrayOutputStream memory=new ByteArrayOutputStream();
            String failure=null;
            int captureRate=RATE;
            try {
                int selectedRate=RATE;
                int min=AudioRecord.getMinBufferSize(selectedRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
                if(min<=0) {
                    selectedRate=FALLBACK_RATE;
                    min=AudioRecord.getMinBufferSize(selectedRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
                }
                if(min<=0) throw new IOException("Microphone format unsupported");
                rec=new AudioRecord(MediaRecorder.AudioSource.MIC,selectedRate,AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,Math.max(min,16384));
                if(rec.getState()!=AudioRecord.STATE_INITIALIZED)throw new IOException("Microphone initialization failed");
                current=rec;
                rec.startRecording();
                short[] buffer=new short[2048];int total=0;int lastUpdate=0;
                // AudioRecord reports the negotiated sample rate for exports.
                int actualRate=rec.getSampleRate();
                captureRate=actualRate;
                while(recording.get() && total<actualRate*MAX_SECONDS) {
                    int read=rec.read(buffer,0,buffer.length);
                    if(read<0) throw new IOException("Recording failed (error " + read + ")");
                    for(int i=0;i<read;i++) {int v=buffer[i];memory.write(v&255);memory.write((v>>8)&255);}
                    total+=read;
                    if(total-lastUpdate>=actualRate/8){
                        lastUpdate=total;float[] f=new float[read];
                        for(int i=0;i<read;i++)f[i]=buffer[i]/32768f;
                        listener.onLevel(f,total/actualRate);
                    }
                }
            } catch(Exception e) {failure=e.getMessage();}
            finally {
                recording.set(false);
                if(rec!=null){ try {rec.stop();}catch(Exception ignored){} rec.release();}
                current=null;
            }
            byte[] pcm=memory.toByteArray();
            float[] samples=new float[pcm.length/2];
            for(int i=0;i<samples.length;i++)samples[i]=(short)((pcm[2*i]&255)|((pcm[2*i+1]&255)<<8))/32768f;
            listener.onFinished(samples,captureRate,failure);
        },"AudioMatrixCapture");
        worker.start();
    }
    public void stop(){ recording.set(false); }
}
