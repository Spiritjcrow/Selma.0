package sol.selma.audiomatrix;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** No third-party tracking, servers or hidden upload. Pure offline audio processing by default. */
public final class MainActivity extends Activity {
    private static final int REQUEST_IMPORT=101, REQUEST_EXPORT=102, REQUEST_DRIVE=103, REQUEST_MIC=104;
    private final int BG=0xff080D16,CARD=0xff111B2B,ACCENT=0xff38EACF,SECONDARY=0xffB58EFF,MUTED=0xff9BAEC3;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AudioRecorder recorder=new AudioRecorder();
    private final Playback playback=new Playback();
    private final AudioProcessor.Settings config=new AudioProcessor.Settings();
    private MidiController midi;
    private SpectrumView spectrum;
    private TextView state,sourceInfo,centerValue,widthValue,focusValue,noiseValue;
    private EQBandView eqBandView;
    private SeekBar centerSlider,widthSlider,focusSlider;
    private Button recordButton,playButton;
    private float[] original,cleaned;
    private int sampleRate=44100;
    private volatile boolean busy=false;
    private boolean driveExport=false;
    private boolean preferNative=false;
    private int tick=0;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        midi=new MidiController(this,new MidiController.OnControl(){
            @Override public void changed(int cc,int value){
                if(cc==74)centerSlider.setProgress(Math.round(value*100f/127f));
                if(cc==71)widthSlider.setProgress(Math.round(value*100f/127f));
                if(cc==7)focusSlider.setProgress(Math.round(value*100f/127f));
            }
            @Override public void status(String message){setState(message);}
        });
        createUi();
        setState("READY · Offline processing · No data sent anywhere");
    }

    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private TextView text(String value,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        return t;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private void gap(LinearLayout parent,int h){ View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private LinearLayout.LayoutParams wrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout box(LinearLayout parent){
        LinearLayout v=vertical();v.setBackground(shape(CARD,16));pad(v,14,14,14,14);
        parent.addView(v,wrap());gap(parent,12);return v;
    }
    private Button button(String label,int color){
        Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setTextColor(color==ACCENT?BG:Color.WHITE);
        b.setAllCaps(false);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        b.setBackground(shape(color,11));b.setMinHeight(dp(48));b.setMinimumHeight(dp(48));
        return b;
    }
    private void addButtonRow(LinearLayout parent,Button... bs){
        LinearLayout r=row();parent.addView(r,wrap());
        for(int i=0;i<bs.length;i++){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
            if(i>0)lp.leftMargin=dp(8);
            r.addView(bs[i],lp);
        }
    }
    private void createUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=vertical();pad(root,16,22,16,28);scroll.addView(root);setContentView(scroll);
        LinearLayout heading=row();root.addView(heading,wrap());
        TextView logo=text("◈",36,ACCENT,true);heading.addView(logo);
        LinearLayout header=vertical();pad(header,10,0,0,0);heading.addView(header);
        header.addView(text("AUDIO MATRIX",23,Color.WHITE,true));
        header.addView(text("SELMA LABS  /  ACOUSTIC STUDIO",10,MUTED,true));
        gap(root,18);
        spectrum=new SpectrumView(this);
        root.addView(spectrum,new LinearLayout.LayoutParams(-1,dp(260)));
        spectrum.setContentDescription("Audio spectrum with frequency selection, spectral waterfall and waveform");
        spectrum.setFrequencyTap(hz->{
            centerSlider.setProgress(Math.round(100*Math.log(Math.max(100,hz)/100.0)/Math.log(8000.0/100)));
            setState(String.format(Locale.US,"Target frequency %.0f Hz selected",hz));
        });
        gap(root,12);
        state=text("",12,ACCENT,true);root.addView(state,wrap());
        sourceInfo=text("NO SOURCE LOADED",11,MUTED,false);pad(sourceInfo,0,6,0,3);root.addView(sourceInfo,wrap());
        gap(root,15);

        LinearLayout inputs=box(root);
        inputs.addView(text("01  SOURCE CAPTURE",14,Color.WHITE,true));gap(inputs,9);
        recordButton=button("● Record",0xffBC415B);
        Button importButton=button("Import WAV",0xff263750);
        addButtonRow(inputs,recordButton,importButton);
        recordButton.setOnClickListener(v->toggleRecord());
        importButton.setOnClickListener(v->openImport());
        gap(inputs,7);
        inputs.addView(text("Microphone or uncompressed WAV • maximum 2-minute recording / 3-minute import",11,MUTED,false));

        LinearLayout filter=box(root);
        filter.addView(text("02  VOICE FOCUS MATRIX",14,Color.WHITE,true));gap(filter,7);
        filter.addView(text("Targets a frequency region; cannot identify an individual speaker.",11,MUTED,false));gap(filter,10);
        centerValue=addSlider(filter,"Focus center",0,100,74,position->{
            config.centerHz=(float)(100*Math.pow(80.0,position/100.0));
            centerValue.setText(String.format(Locale.US,"FOCUS CENTER  •  %.0f Hz",config.centerHz));refreshSelection();
        });
        centerSlider=(SeekBar)filter.getChildAt(filter.getChildCount()-1);
        widthValue=addSlider(filter,"Band width",0,100,60,position->{
            config.widthHz=300f+position*76f;
            widthValue.setText(String.format(Locale.US,"BAND WIDTH  •  %.0f Hz",config.widthHz));refreshSelection();
        });
        widthSlider=(SeekBar)filter.getChildAt(filter.getChildCount()-1);
        focusValue=addSlider(filter,"Filter strength",0,100,80,position->{
            config.filterStrength=position/100f;
            focusValue.setText("FILTER STRENGTH  •  "+position+"%");
        });
        focusSlider=(SeekBar)filter.getChildAt(filter.getChildCount()-1);
        Switch bandSwitch=addSwitch(filter,"Enable speech frequency focus",true,(b)->config.bandFocus=b);
        Switch autoSwitch=addSwitch(filter,"Auto loudness / anti-clipping",true,(b)->config.autoGain=b);
        noiseValue=addSlider(filter,"Noise reduction",0,100,35,position->{
            config.noiseReduction=position/100f;
            noiseValue.setText("NOISE REDUCTION  •  "+position+"%");
        });
        filter.addView(text("TEN-BAND OCTAVE EQ  •  DRAG DOTS UP OR DOWN",11,MUTED,true));gap(filter,6);
        eqBandView=new EQBandView(this);
        filter.addView(eqBandView,new LinearLayout.LayoutParams(-1,dp(190)));
        eqBandView.setOnBandChanged((index,gain)->config.bandDb[index]=gain);
        gap(filter,6);
        Button resetEq=button("Reset 10-band EQ",0xff293D57);
        filter.addView(resetEq,wrap());
        resetEq.setOnClickListener(v->{
            for(int i=0;i<config.bandDb.length;i++) config.bandDb[i]=0;
            eqBandView.setAllGains(config.bandDb);
            setState("10-band EQ reset to flat");
        });
        gap(filter,8);
        refreshSelection();

        LinearLayout processing=box(root);
        processing.addView(text("03  PROCESS & MONITOR",14,Color.WHITE,true));gap(processing,10);
        addSwitch(processing,"Native C++ DSP (experimental)",false,on->{
            preferNative=on;
            setState(on?(NativeDsp.isAvailable()?"Native C++ processing selected":"JNI unavailable. Java fallback will be used."):"Java processing selected");
        });
        gap(processing,5);
        Button processButton=button("✦ Enhance Recording",ACCENT);
        processing.addView(processButton,wrap());processButton.setOnClickListener(v->process());
        gap(processing,8);
        playButton=button("▶ Play enhanced",0xff293D57);
        Button compareButton=button("▶ Original",0xff293D57);
        addButtonRow(processing,playButton,compareButton);
        playButton.setOnClickListener(v->preview(true));
        compareButton.setOnClickListener(v->preview(false));
        gap(processing,7);
        Button stopButton=button("■ Stop playback",0xff263750);
        processing.addView(stopButton,wrap());stopButton.setOnClickListener(v->{playback.stop();setState("Playback stopped");});

        LinearLayout output=box(root);
        output.addView(text("04  EXPORT & CONNECT",14,Color.WHITE,true));gap(output,9);
        Button saveButton=button("Save enhanced WAV",ACCENT);
        Button driveButton=button("Save to Drive…",0xff58468A);
        addButtonRow(output,saveButton,driveButton);
        saveButton.setOnClickListener(v->export(false));
        driveButton.setOnClickListener(v->export(true));
        gap(output,8);
        output.addView(text("Save to Drive opens Android’s file picker. Select Google Drive as the destination. No automatic cloud upload.",11,MUTED,false));
        gap(output,6);
        addSwitch(output,"MIDI controller (CC74/71/7)",false,(on)->{
            if(on)midi.enable();else {midi.disable();setState("MIDI disabled");}
        });
        gap(root,7);
        root.addView(text("PRIVATE BY DEFAULT  •  LOCAL DSP  •  NO TELEMETRY",10,MUTED,true));
    }

    private interface IntChange{void changed(int value);}
    private TextView addSlider(LinearLayout parent,String title,int min,int max,int initial,IntChange onChange){
        TextView t=text(title.toUpperCase(Locale.US),11,MUTED,true);parent.addView(t,wrap());
        SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(initial-min);bar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        bar.setThumbTintList(ColorStateList.valueOf(SECONDARY));parent.addView(bar,wrap());
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int progress,boolean fromUser){onChange.changed(progress+min);}
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });
        // Post initialization until after the caller stores its label and SeekBar fields.
        ui.post(()->onChange.changed(initial));
        return t;
    }
    private interface Toggle{void changed(boolean enabled);}
    @SuppressWarnings("deprecation")
    private Switch addSwitch(LinearLayout parent,String label,boolean checked,Toggle toggle){
        Switch s=new Switch(this);s.setText(label);s.setTextColor(Color.WHITE);s.setTextSize(12);
        s.setChecked(checked);s.setThumbTintList(ColorStateList.valueOf(ACCENT));
        pad(s,0,9,0,9);parent.addView(s,wrap());
        s.setOnCheckedChangeListener((CompoundButton b,boolean enabled)->toggle.changed(enabled));return s;
    }
    private void refreshSelection(){if(spectrum!=null)spectrum.setSelection(config.centerHz,config.widthHz);}
    private void setState(String text){ui.post(()->{if(state!=null)state.setText(text);});}
    private void alert(String message){ui.post(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}

    private void toggleRecord(){
        if(busy){alert("Wait until processing finishes");return;}
        if(recorder.isRecording()) {recorder.stop();recordButton.setText("● Record");setState("Finishing recording…");return;}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQUEST_MIC);return;
        }
        playback.stop();cleaned=null;recordButton.setText("■ Stop recording");setState("Recording microphone · tap Stop when done");
        recorder.start(new AudioRecorder.Listener(){
            @Override public void onLevel(float[] samples,int seconds){
                if(++tick%2==0)ui.post(()->{
                    spectrum.updateSpectrum(samples);state.setText("● RECORDING  "+seconds+"s / "+AudioRecorder.MAX_SECONDS+"s");
                });
            }
            @Override public void onFinished(float[] audio,int rate,String problem){
                ui.post(()->{
                    original=audio;sampleRate=rate;cleaned=null;
                    recordButton.setText("● Record");
                    spectrum.setAudio(audio);
                    sourceInfo.setText(String.format(Locale.US,"MIC INPUT  •  %.1f s  •  %d Hz  •  MONO",audio.length/(float)rate,rate));
                    setState(problem!=null?"Recording error: "+problem:"Recording ready. Adjust filter, then enhance.");
                });
            }
        });
    }
    private void openImport(){
        if(busy||recorder.isRecording()){alert("Stop the current operation first");return;}
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("audio/*");intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent,REQUEST_IMPORT);
    }
    private void process(){
        if(original==null||original.length==0){alert("Record or import a WAV first");return;}
        if(busy||recorder.isRecording()){alert("Stop recording or wait for processing");return;}
        playback.stop();busy=true;setState("Enhancing audio · 0%");
        AudioProcessor.Settings snapshot=new AudioProcessor.Settings();
        snapshot.centerHz=config.centerHz;snapshot.widthHz=config.widthHz;snapshot.filterStrength=config.filterStrength;
        snapshot.noiseReduction=config.noiseReduction;
        System.arraycopy(config.bandDb,0,snapshot.bandDb,0,config.bandDb.length);
        snapshot.autoGain=config.autoGain;snapshot.bandFocus=config.bandFocus;
        float[] input=original;int rate=sampleRate;boolean nativeRequested=preferNative;
        worker.execute(()->{
            try {
                float[] output=nativeRequested ? NativeDsp.process(input,rate,snapshot)
                    : AudioProcessor.process(input,rate,snapshot,percent->setState("Enhancing audio · "+percent+"%"));
                ui.post(()->{cleaned=output;busy=false;spectrum.setAudio(output);setState("Enhanced WAV ready · Preview or export");});
            } catch(Exception e){ui.post(()->{busy=false;setState("Processing failed: "+e.getMessage());});}
        });
    }
    private void preview(boolean enhanced){
        if(busy||recorder.isRecording()){alert("Finish current operation first");return;}
        float[] selected=enhanced?cleaned:original;
        if(selected==null||selected.length==0){alert(enhanced?"Enhance a recording first":"Record or import a WAV first");return;}
        playback.play(selected,sampleRate,()->setState("Playback completed"));
        spectrum.setAudio(selected);setState(enhanced?"▶ Previewing enhanced audio":"▶ Previewing original audio");
    }
    private void export(boolean toDrive){
        if(busy||recorder.isRecording()){alert("Finish current operation first");return;}
        if(cleaned==null){alert("Enhance a recording before exporting");return;}
        driveExport=toDrive;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,"AudioMatrix-Enhanced.wav");
        startActivityForResult(i,toDrive?REQUEST_DRIVE:REQUEST_EXPORT);
        if(toDrive)setState("Choose Google Drive from the file picker to save there");
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==REQUEST_IMPORT){
            busy=true;setState("Opening WAV source…");
            worker.execute(()->{
                try(InputStream stream=getContentResolver().openInputStream(uri)){
                    if(stream==null)throw new IllegalArgumentException("Cannot read file");
                    WavCodec.Audio imported=WavCodec.read(stream);
                    ui.post(()->{original=imported.samples;cleaned=null;sampleRate=imported.rate;busy=false;
                        spectrum.setAudio(original);
                        sourceInfo.setText(String.format(Locale.US,"IMPORTED WAV  •  %.1f s  •  %d Hz  •  MONO MIX",original.length/(float)sampleRate,sampleRate));
                        setState("WAV imported. Adjust controls, then enhance.");
                    });
                }catch(Exception e){ui.post(()->{busy=false;setState("Import failed: "+e.getMessage());});}
            });
        } else if(request==REQUEST_EXPORT||request==REQUEST_DRIVE){
            float[] samples=cleaned;int rate=sampleRate;busy=true;setState("Writing WAV…");
            worker.execute(()->{
                try(OutputStream stream=getContentResolver().openOutputStream(uri,"w")){
                    if(stream==null)throw new IllegalArgumentException("Cannot write selected file");
                    WavCodec.write(stream,samples,rate);
                    ui.post(()->{busy=false;setState("Saved enhanced audio to chosen location ✓");});
                }catch(Exception e){ui.post(()->{busy=false;setState("Export failed: "+e.getMessage());});}
            });
        }
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==REQUEST_MIC){
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)toggleRecord();
            else setState("Microphone permission denied. WAV import still works.");
        }
    }
    @Override protected void onDestroy(){
        recorder.stop();playback.stop();midi.disable();worker.shutdown();super.onDestroy();
    }
}
