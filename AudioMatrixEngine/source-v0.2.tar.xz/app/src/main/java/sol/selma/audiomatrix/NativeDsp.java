/* PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved. */
package sol.selma.audiomatrix;

/** Optional native offline DSP with reliable Java fallback if JNI cannot load. */
public final class NativeDsp {
    private static final boolean AVAILABLE;
    static { boolean loaded=false;
        try { System.loadLibrary("audiomatrix_native");loaded=true; }
        catch (UnsatisfiedLinkError | SecurityException ignored) { }
        AVAILABLE=loaded;
    }
    private NativeDsp() {}
    public static boolean isAvailable(){return AVAILABLE;}
    private static native float[] processNative(float[] source,int rate,float center,float width,
        float strength,float denoise,float[] gains,boolean autoGain,boolean focus);
    public static float[] process(float[] source,int rate,AudioProcessor.Settings config){
        if(AVAILABLE){
            try {
                float[] result=processNative(source,rate,config.centerHz,config.widthHz,
                    config.filterStrength,config.noiseReduction,config.bandDb,config.autoGain,config.bandFocus);
                if(result!=null&&result.length==source.length)return result;
            } catch(UnsatisfiedLinkError | RuntimeException ignored) { }
        }
        return AudioProcessor.process(source,rate,config,null);
    }
}
