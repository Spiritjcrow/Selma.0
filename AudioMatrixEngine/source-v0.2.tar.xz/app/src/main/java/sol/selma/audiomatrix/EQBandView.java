/* PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved. */
package sol.selma.audiomatrix;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** Interactive ten-band EQ. Each point controls one octave-spaced peaking filter. */
public final class EQBandView extends View {
    public interface OnBandChanged { void changed(int index,float gainDb); }
    private OnBandChanged listener;
    private final float[] gains=new float[10];
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int aqua=Color.rgb(56,234,207),muted=Color.rgb(148,173,196);
    private final String[] labels={"31","63","125","250","500","1k","2k","4k","8k","16k"};
    public EQBandView(Context c) { super(c);setContentDescription("Ten-band equalizer, drag each frequency band to set gain"); }
    public void setOnBandChanged(OnBandChanged cb) { listener=cb; }
    public void setAllGains(float[] next) {
        for(int i=0;i<gains.length;i++) gains[i]=i<next.length?Math.max(-24,Math.min(24,next[i])):0;
        invalidate();
    }
    private float d(float n){return n*getResources().getDisplayMetrics().density;}
    private float yOf(float db){return d(16)+(24-db)/48f*Math.max(1,getHeight()-d(51));}
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left=d(16),right=getWidth()-d(16),w=(right-left)/9f;
        for(int r=-24;r<=24;r+=12){
            float y=yOf(r);paint.setStrokeWidth(d(r==0?1.5f:.8f));
            paint.setColor(r==0?0xff4d647a:0xff283a50);
            canvas.drawLine(left,y,right,y,paint);
        }
        paint.setTextSize(d(9));paint.setTextAlign(Paint.Align.CENTER);
        for(int i=0;i<gains.length;i++){
            float x=left+i*w,y=yOf(gains[i]);
            paint.setColor(0xff4b6480);paint.setStrokeWidth(d(3));
            canvas.drawLine(x,yOf(-24),x,yOf(24),paint);
            paint.setColor(aqua);canvas.drawCircle(x,y,d(7),paint);
            paint.setColor(muted);canvas.drawText(labels[i],x,getHeight()-d(10),paint);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        int action=event.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE){
            float left=d(16),available=Math.max(1,getWidth()-d(32));
            int index=Math.max(0,Math.min(9,Math.round((event.getX()-left)*9/available)));
            float range=Math.max(1,getHeight()-d(51));
            float gain=Math.max(-24,Math.min(24,24-48*(event.getY()-d(16))/range));
            gains[index]=Math.round(gain*2)/2f;
            if(listener!=null)listener.changed(index,gains[index]);
            invalidate();return true;
        }
        if(action==MotionEvent.ACTION_UP){performClick();return true;}
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
