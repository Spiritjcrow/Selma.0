package sol.selma.audiomatrix;

import java.io.*;
import java.nio.*;

/** PCM mono/stereo WAV decoder (8/16/24/32-bit PCM, IEEE32 float) and 16-bit mono encoder. */
public final class WavCodec {
    private WavCodec() {}
    public static final class Audio {
        public final float[] samples;
        public final int rate;
        Audio(float[] s, int r) { samples=s; rate=r; }
    }
    private static int le16(byte[] a, int p) {
        return (a[p]&255)|((a[p+1]&255)<<8);
    }
    private static int le32(byte[] a, int p) {
        return (a[p]&255)|((a[p+1]&255)<<8)|((a[p+2]&255)<<16)|((a[p+3]&255)<<24);
    }
    public static Audio read(InputStream input) throws IOException {
        // 70 MB hard cap: protects low-memory Android devices from accidental giant files.
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] block=new byte[8192]; int n, count=0;
        while ((n=input.read(block))!=-1) {
            count+=n; if (count>70_000_000) throw new IOException("WAV too large (70 MB limit)");
            out.write(block,0,n);
        }
        byte[] b=out.toByteArray();
        if (b.length<44 || !fourcc(b,0,"RIFF") || !fourcc(b,8,"WAVE"))
            throw new IOException("Choose an uncompressed WAV file");
        int channels=0,rate=0,depth=0,format=0,align=0,dataPos=-1,dataLen=0;
        int p=12;
        while (p+8<=b.length) {
            int chunkSize=le32(b,p+4);
            if (chunkSize<0 || (long)p+8+chunkSize>b.length) throw new IOException("Invalid WAV chunk");
            if (fourcc(b,p,"fmt ") && chunkSize>=16) {
                format=le16(b,p+8); channels=le16(b,p+10);
                rate=le32(b,p+12); align=le16(b,p+20); depth=le16(b,p+22);
            } else if (fourcc(b,p,"data")) { dataPos=p+8; dataLen=chunkSize; }
            p+=8+chunkSize+(chunkSize&1);
        }
        if (dataPos<0 || channels<1 || channels>2 || rate<8000 || rate>192000 || align<=0 ||
            !((format==1&&(depth==8||depth==16||depth==24||depth==32))||(format==3&&depth==32)))
            throw new IOException("Supported: PCM WAV 8/16/24/32-bit or float32, mono/stereo");
        int frames=dataLen/align;
        if (frames>rate*180) throw new IOException("Limit: first 3 minutes. Trim the source WAV.");
        float[] mono=new float[frames]; int bytes=depth/8;
        for(int i=0;i<frames;i++) {
            double sum=0;
            for(int c=0;c<channels;c++) {
                int j=dataPos+i*align+c*bytes; float v;
                if (format==3) v=Float.intBitsToFloat(le32(b,j));
                else if(depth==8) v=((b[j]&255)-128)/128f;
                else if(depth==16) v=(short)le16(b,j)/32768f;
                else if(depth==24) { int x=(b[j]&255)|((b[j+1]&255)<<8)|((b[j+2]&255)<<16); if((x&0x800000)!=0) x|=0xff000000; v=x/8388608f; }
                else v=le32(b,j)/2147483648f;
                sum+=Float.isFinite(v)?v:0;
            }
            mono[i]=(float)(sum/channels);
        }
        return new Audio(mono,rate);
    }
    private static boolean fourcc(byte[] b,int p,String s){ return b.length>=p+4 && b[p]==s.charAt(0)&&b[p+1]==s.charAt(1)&&b[p+2]==s.charAt(2)&&b[p+3]==s.charAt(3); }
    public static void write(OutputStream out,float[] samples,int rate) throws IOException {
        long dataSize=(long)samples.length*2;
        if(dataSize>Integer.MAX_VALUE-44) throw new IOException("Recording too large");
        DataOutputStream d=new DataOutputStream(new BufferedOutputStream(out));
        d.writeBytes("RIFF"); little32(d,(int)(36+dataSize)); d.writeBytes("WAVEfmt ");
        little32(d,16); little16(d,1); little16(d,1); little32(d,rate);
        little32(d,rate*2); little16(d,2); little16(d,16); d.writeBytes("data"); little32(d,(int)dataSize);
        for(float s:samples) { float v=Math.max(-1f,Math.min(1f,s)); little16(d,Math.round(v*32767)); }
        d.flush();
    }
    private static void little16(DataOutputStream d,int v)throws IOException {d.writeByte(v&255);d.writeByte((v>>8)&255);}
    private static void little32(DataOutputStream d,int v)throws IOException {little16(d,v);little16(d,v>>16);}
}
