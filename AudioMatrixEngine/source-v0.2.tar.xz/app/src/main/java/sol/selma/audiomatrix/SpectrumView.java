package sol.selma.audiomatrix;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Spectrum + mini-waterfall + waveform overview, with tap-to-select a frequency. */
public final class SpectrumView extends View {
    public interface FrequencyTap {void onFrequency(float hz);}
    private FrequencyTap tapListener;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] current=new float[96];
    private final float[][] history=new float[36][96];
    private int historyWrite=0,valid=0;
    private float[] audio;
    private float center=2300,width=3200;
    private final int text=Color.rgb(150,173,199),aqua=Color.rgb(54,238,205),purple=Color.rgb(179,134,255);
    public SpectrumView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setFrequencyTap(FrequencyTap listener){tapListener=listener;}
    public void setSelection(float h,float w){center=h;width=w;invalidate();}
    public void setAudio(float[] samples){audio=samples;updateSpectrum(samples);}
    public void updateSpectrum(float[] samples){
        float[] next=AudioProcessor.spectrum(samples);
        System.arraycopy(next,0,current,0,current.length);
        System.arraycopy(next,0,history[historyWrite],0,current.length);
        historyWrite=(historyWrite+1)%history.length;
        valid=Math.min(valid+1,history.length);
        invalidate();
    }
    private float d(float dp){return dp*getResources().getDisplayMetrics().density;}
    private static double hzToNorm(double hz){return Math.log(Math.max(40,hz)/40.0)/Math.log(11025.0/40);}
    private static double normToHz(double norm){return 40*Math.pow(11025.0/40,Math.max(0,Math.min(1,norm)));}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);int w=getWidth(),h=getHeight();float left=d(14),right=w-d(14),top=d(16);
        p.setColor(Color.rgb(15,25,40));c.drawRoundRect(new RectF(0,0,w,h),d(16),d(16),p);
        float graphBottom=h*.52f,waterTop=graphBottom+d(27),waterBottom=h-d(37);
        float selectionLeft=(float)(left+Math.max(0,hzToNorm(center-width/2f))*(right-left));
        float selectionRight=(float)(left+Math.min(1,hzToNorm(center+width/2f))*(right-left));
        p.setColor(Color.argb(33,54,238,205));c.drawRect(selectionLeft,top,selectionRight,graphBottom,p);
        p.setStrokeWidth(d(1));p.setColor(Color.rgb(33,53,72));
        for(int i=0;i<=4;i++){float y=top+(graphBottom-top)*i/4;c.drawLine(left,y,right,y,p);}
        for(int i=0;i<=5;i++){float x=left+(right-left)*i/5;c.drawLine(x,top,x,graphBottom,p);}
        Path path=new Path();
        for(int i=0;i<current.length;i++){
            float x=left+i*(right-left)/(current.length-1f);
            float y=graphBottom-current[i]*(graphBottom-top);
            if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
        }
        p.setColor(aqua);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        p.setColor(text);p.setTextSize(d(10));c.drawText("SPECTRUM  |  TAP TO TARGET FREQUENCY",left,top-d(5),p);
        c.drawText("SPECTRAL HISTORY",left,waterTop-d(7),p);
        int cols=history.length;
        float cw=(right-left)/96f,ch=(waterBottom-waterTop)/cols;
        for(int row=0;row<valid;row++){
            int at=(historyWrite-1-row+cols)%cols;
            float y=waterTop+row*ch;
            for(int col=0;col<96;col++){
                float v=history[at][col];
                p.setColor(Color.rgb((int)(24+131*v),(int)(34+208*v),(int)(50+143*v)));
                float x=left+col*cw;
                c.drawRect(x,y,x+cw+0.5f,y+ch+0.5f,p);
            }
        }
        if(audio!=null&&audio.length>0){
            float waveY=h-d(16),amp=d(10);
            p.setColor(purple);p.setStrokeWidth(d(1));
            int slices=Math.min(140,Math.max(1,(int)((right-left)/d(2))));
            for(int i=0;i<slices;i++){
                int from=i*audio.length/slices,to=Math.min(audio.length,(i+1)*audio.length/slices);
                float peak=0;int step=Math.max(1,(to-from)/100);
                for(int j=from;j<to;j+=step)peak=Math.max(peak,Math.abs(audio[j]));
                float x=left+i*(right-left)/slices;
                c.drawLine(x,waveY-peak*amp,x,waveY+peak*amp,p);
            }
        }
        p.setColor(text);p.setTextSize(d(9));c.drawText("40 Hz",left,h-d(28),p);c.drawText("11 kHz",right-d(32),h-d(28),p);
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP){
            float x=Math.max(0,Math.min(1,(event.getX()-d(14))/Math.max(1,getWidth()-d(28))));
            if(tapListener!=null)tapListener.onFrequency((float)normToHz(x));
            performClick();return true;
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
