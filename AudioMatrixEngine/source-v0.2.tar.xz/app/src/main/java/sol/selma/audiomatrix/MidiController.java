package sol.selma.audiomatrix;

import android.content.Context;
import android.media.midi.*;
import android.os.Handler;
import android.os.Looper;

/** Optional USB/Bluetooth MIDI controller: CC74=center, CC71=width, CC7=filter strength. */
public final class MidiController {
    public interface OnControl {void changed(int cc,int value);void status(String message);}
    private final MidiManager midi;
    private final OnControl listener;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MidiDevice device;
    private MidiOutputPort port;
    private final MidiReceiver receiver=new MidiReceiver(){
        @Override public void onSend(byte[] msg,int offset,int count,long timestamp){
            for(int i=offset;i+2<offset+count;i++){
                int status=msg[i]&255;
                if((status&0xF0)==0xB0){int cc=msg[i+1]&127, val=msg[i+2]&127;
                    if(cc==74||cc==71||cc==7)handler.post(()->listener.changed(cc,val));
                    i+=2;
                }
            }
        }
    };
    public MidiController(Context context,OnControl listener){midi=(MidiManager)context.getSystemService(Context.MIDI_SERVICE);this.listener=listener;}
    public void enable(){
        if(midi==null){listener.status("MIDI is not available on this device");return;}
        MidiDeviceInfo[] devices=midi.getDevices();
        if(devices.length==0){listener.status("No MIDI device detected. Connect one and re-enable MIDI.");return;}
        MidiDeviceInfo target=null;
        for(MidiDeviceInfo info:devices) if(info.getOutputPortCount()>0){target=info;break;}
        if(target==null){listener.status("MIDI device has no output port");return;}
        midi.openDevice(target,opened->{
            if(opened==null){listener.status("Could not open MIDI device");return;}
            device=opened;
            port=opened.openOutputPort(0);
            if(port==null){try{opened.close();}catch(Exception ignored){}device=null;listener.status("Cannot open MIDI output port");return;}
            port.connect(receiver);
            listener.status("MIDI connected: CC74 center, CC71 width, CC7 strength");
        },handler);
    }
    public void disable(){
        if(port!=null){try{port.disconnect(receiver);port.close();}catch(Exception ignored){}port=null;}
        if(device!=null){try{device.close();}catch(Exception ignored){}device=null;}
    }
}
