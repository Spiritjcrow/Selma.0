package sol.selma.audiomatrix;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import java.util.concurrent.atomic.AtomicBoolean;

/** Local preview. Writes PCM to the playback track off the UI thread. */
public final class Playback {
    private final AtomicBoolean playing=new AtomicBoolean(false);
    private volatile AudioTrack track;
    public boolean isPlaying(){return playing.get();}
    public void play(float[] audio,int rate,Runnable onComplete) {
        stop();
        if(audio==null||audio.length==0)return;
        playing.set(true);
        new Thread(()->{
            AudioTrack t=null;
            try {
                int min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
                if(min<0)return;
                t=new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(Math.max(min,8192))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
                track=t;t.play();short[] block=new short[2048];int pos=0;
                while(playing.get()&&pos<audio.length){
                    int count=Math.min(block.length,audio.length-pos);
                    for(int i=0;i<count;i++)block[i]=(short)Math.round(Math.max(-1,Math.min(1,audio[pos+i]))*32767);
                    int n=t.write(block,0,count);
                    if(n<=0)break;
                    pos+=n;
                }
                if(playing.get()){t.stop();}
            } catch(Exception ignored){}
            finally {playing.set(false); if(t!=null){try {t.pause();t.flush();t.release();} catch(Exception ignored){}} track=null;onComplete.run();}
        },"AudioMatrixPreview").start();
    }
    public void stop(){playing.set(false);AudioTrack t=track;if(t!=null)try{t.pause();t.flush();}catch(Exception ignored){}}
}
