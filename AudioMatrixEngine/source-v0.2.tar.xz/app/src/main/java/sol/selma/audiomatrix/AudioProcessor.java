/* PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved. */
package sol.selma.audiomatrix;

import java.util.Arrays;

/** Offline FFT/STFT DSP. This is frequency-aware filtering, NOT neural speaker separation. */
public final class AudioProcessor {
    public static final int FFT_SIZE = 2048;
    private static final int HOP = 512;

    private AudioProcessor() {}

    public static final class Settings {
        public float centerHz = 2300f;
        public float widthHz = 3200f;
        public float filterStrength = 0.8f;
        public float noiseReduction = 0.35f;
        /** Ten octave centers from 31.25 Hz to 16 kHz; independent gains in dB. */
        public final float[] bandDb = new float[]{0f,0f,0f,0f,0f,0f,0f,0f,0f,0f};
        public boolean autoGain = true;
        public boolean bandFocus = true;
    }

    public interface Progress { void update(int percent); }

    public static float[] process(float[] input, int rate, Settings params, Progress callback) {
        if(input == null || input.length == 0) return new float[0];
        final int len=input.length, n=FFT_SIZE, hop=HOP;
        // Circular overlap-add avoids multiple recording-length buffers on low-memory phones.
        final float[] accum=new float[n];
        final float[] norms=new float[n];
        final float[] output=new float[len];
        final double[] wr=new double[n], wi=new double[n];
        final double[] window=new double[n];
        for(int i=0;i<n;i++) window[i]=0.5-0.5*Math.cos(2*Math.PI*i/(n-1));
        final int bins=n/2+1;
        final double[] noiseFloor = new double[bins];
        // Probe first ~0.35s as a *heuristic*, not a proven noise-only interval.
        int probeFrames=Math.min(12,Math.max(1,(len-n)/hop));
        for(int frame=0;frame<probeFrames;frame++) {
            int offset=frame*hop;
            for(int j=0;j<n;j++) { int ix=offset+j; wr[j]=(ix<len?input[ix]:0)*window[j];wi[j]=0; }
            fft(wr,wi,false);
            for(int k=0;k<bins;k++) noiseFloor[k]+=Math.hypot(wr[k],wi[k]);
        }
        for(int k=0;k<bins;k++) noiseFloor[k]/=probeFrames;
        int frames=Math.max(1,(len+hop-1)/hop);
        int lastProgress=-1;
        for(int frame=0;frame<frames;frame++) {
            int start=frame*hop;
            Arrays.fill(wr,0);Arrays.fill(wi,0);
            for(int i=0;i<n && start+i<len;i++) wr[i]=input[start+i]*window[i];
            fft(wr,wi,false);
            for(int k=0;k<=n/2;k++) {
                double hz=(double)k*rate/n;
                double mask=1;
                if(params.bandFocus) {
                    double halfWidth=Math.max(120, params.widthHz/2.0);
                    double dist=Math.abs(hz-params.centerHz);
                    double edge=0.1*halfWidth + 100;
                    double outside=Math.max(0,Math.min(1,(dist-(halfWidth-edge))/(2*edge)));
                    outside=outside*outside*(3-2*outside);
                    mask=1.0-(0.95*params.filterStrength)*outside;
                }
                // Smooth octave-spaced frequency-domain peaking EQ. Avoids the
                // abrupt band discontinuities that produce ringing artifacts.
                double eqDb=eqAtHz(hz,params.bandDb);
                double mag=Math.hypot(wr[k],wi[k]);
                // Soft stationary-noise suppression, retaining a nonzero floor.
                double floor=noiseFloor[k];
                double ratio=mag/(floor+1e-6);
                double gate=1.0-params.noiseReduction*0.83*Math.max(0,Math.min(1,(2.5-ratio)/2.5));
                double mult=mask*gate*Math.pow(10,eqDb/20.0);
                wr[k]*=mult; wi[k]*=mult;
                if(k>0 && k<n/2) { wr[n-k]*=mult;wi[n-k]*=mult; }
            }
            fft(wr,wi,true);
            for(int i=0;i<n && start+i<len;i++) {
                double win=window[i];
                int slot=(start+i)&(n-1);
                accum[slot]+=(float)(wr[i]*win);
                norms[slot]+=(float)(win*win);
            }
            for(int i=start;i<Math.min(start+hop,len);i++) {
                int slot=i&(n-1);
                output[i]=norms[slot]>1e-6f?accum[slot]/norms[slot]:0;
                accum[slot]=0;norms[slot]=0;
            }
            int percent=(frame+1)*100/frames;
            if(callback!=null && percent!=lastProgress && percent%5==0) {callback.update(percent);lastProgress=percent;}
        }
        float peak=0;
        double power=0;
        for(int i=0;i<len;i++) {
            peak=Math.max(peak,Math.abs(output[i]));
            power+=output[i]*output[i];
        }
        double rms=Math.sqrt(power/len);
        double gain=1;
        if(params.autoGain && rms>1e-7) gain=Math.min(3.0,0.1259/rms); // -18 dBFS RMS target
        if(peak*gain>0.94) gain=0.94/Math.max(1e-8,peak); // true sample peak safety
        for(int i=0;i<len;i++) output[i]=(float)Math.max(-1,Math.min(1,output[i]*gain));
        return output;
    }

    /** Continuous log-frequency response; each +/-24 dB band spans roughly an octave. */
    static double eqAtHz(double hz, float[] gains) {
        if (hz < 1 || gains == null) return 0;
        double log2 = Math.log(hz / 31.25) / Math.log(2);
        double sum=0;
        for (int i=0; i<Math.min(10,gains.length); i++) {
            double octaves=(log2-i)/0.55;
            sum+=Math.max(-24,Math.min(24,gains[i]))*Math.exp(-0.5*octaves*octaves);
        }
        return Math.max(-36,Math.min(36,sum));
    }

    static double lerp(double a,double b,double t) { return a+(b-a)*Math.max(0,Math.min(1,t)); }

    /** In-place radix-2 complex FFT; inverse has 1/n normalization. */
    static void fft(double[] re,double[] im,boolean inverse) {
        int n=re.length;
        for(int i=1,j=0;i<n;i++) {
            int bit=n>>1;
            for(; (j&bit)!=0;bit>>=1)j^=bit;
            j^=bit;
            if(i<j) { double r=re[i];re[i]=re[j];re[j]=r;double m=im[i];im[i]=im[j];im[j]=m; }
        }
        for(int step=2;step<=n;step<<=1) {
            double ang=(inverse?2:-2)*Math.PI/step;
            double wpr=Math.cos(ang),wpi=Math.sin(ang);
            for(int start=0;start<n;start+=step) {
                double ur=1,ui=0;
                for(int j=0;j<step/2;j++) {
                    int even=start+j,odd=even+step/2;
                    double tr=ur*re[odd]-ui*im[odd];
                    double ti=ur*im[odd]+ui*re[odd];
                    re[odd]=re[even]-tr;im[odd]=im[even]-ti;
                    re[even]+=tr;im[even]+=ti;
                    double nwr=ur*wpr-ui*wpi;ui=ur*wpi+ui*wpr;ur=nwr;
                }
            }
        }
        if(inverse) for(int i=0;i<n;i++){re[i]/=n;im[i]/=n;}
    }

    public static float[] spectrum(float[] data) {
        int n=FFT_SIZE;
        float[] bands=new float[96];
        if(data==null || data.length==0) return bands;
        double[] re=new double[n],im=new double[n];
        int start=Math.max(0,data.length-n);
        for(int i=0;i<n && i<data.length;i++) re[i]=data[start+i]*(0.5-0.5*Math.cos(2*Math.PI*i/(n-1)));
        fft(re,im,false);
        for(int b=0;b<bands.length;b++) {
            double lower=2*Math.pow(512.0/2.0,b/96.0);
            double upper=2*Math.pow(512.0/2.0,(b+1)/96.0);
            int lo=Math.min(n/2,Math.max(1,(int)Math.floor(lower)));
            int hi=Math.min(n/2,Math.max(lo+1,(int)Math.ceil(upper)));
            double peak=0;
            for(int k=lo;k<=hi;k++) peak=Math.max(peak,Math.hypot(re[k],im[k])/n);
            // 0=quiet, 1=0dBFS-like visual level.
            bands[b]=(float)Math.max(0,Math.min(1,(20*Math.log10(peak+1e-7)+95)/80.0));
        }
        return bands;
    }
}
