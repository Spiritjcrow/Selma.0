// PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.
#include "AudioDsp.h"
#include <jni.h>
#include <algorithm>
#include <exception>

// JNI arrays copy is performed only in background processing, never in audio callbacks.
extern "C" JNIEXPORT jfloatArray JNICALL
Java_sol_selma_audiomatrix_NativeDsp_processNative(JNIEnv* env,jclass,jfloatArray audio,
    jint rate,jfloat center,jfloat width,jfloat strength,jfloat denoise,
    jfloatArray gains,jboolean autoGain,jboolean focus) {
    if(!audio||!gains||env->GetArrayLength(gains)<10)return nullptr;
    const auto n=env->GetArrayLength(audio);
    if(n<=0||rate<8000||rate>192000||n>rate*180)return nullptr;
    jfloat* data=env->GetFloatArrayElements(audio,nullptr);
    if(!data)return nullptr;
    audiomatrix::Settings cfg;
    cfg.centerHz=center;cfg.widthHz=width;cfg.strength=strength;cfg.denoise=denoise;
    cfg.autoGain=autoGain;cfg.bandFocus=focus;
    env->GetFloatArrayRegion(gains,0,10,cfg.gains);
    std::vector<float> result;
    try{result=audiomatrix::process(data,n,rate,cfg);}
    catch(const std::exception&){env->ReleaseFloatArrayElements(audio,data,JNI_ABORT);return nullptr;}
    env->ReleaseFloatArrayElements(audio,data,JNI_ABORT);
    jfloatArray out=env->NewFloatArray(static_cast<jsize>(result.size()));
    if(out)env->SetFloatArrayRegion(out,0,static_cast<jsize>(result.size()),result.data());
    return out;
}
