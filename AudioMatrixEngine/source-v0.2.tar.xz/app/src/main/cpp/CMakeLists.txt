cmake_minimum_required(VERSION 3.22.1)
project(AudioMatrixEngine LANGUAGES CXX)
# Self-contained native DSP: no hard-coded paths or unbundled dependencies.
# Oboe, TFLite and KissFFT may be added as optional licensed backends after
# validated models and Android device performance tests.
add_library(audiomatrix_native SHARED AudioDsp.cpp NativeBridge.cpp)
target_compile_features(audiomatrix_native PRIVATE cxx_std_17)
target_compile_options(audiomatrix_native PRIVATE -Wall -Wextra -Werror=return-type)
