// PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.
#include "AudioDsp.h"
#include <algorithm>
#include <cmath>
#include <complex>
#include <limits>
#include <stdexcept>

namespace audiomatrix {
namespace {
constexpr int N=2048;
constexpr int HOP=512;
constexpr double PI=3.14159265358979323846;
using Complex=std::complex<double>;
void fft(std::vector<Complex>& a,bool inverse) {
    const auto n=a.size();
    if(n<2 || (n&(n-1))!=0) throw std::invalid_argument("FFT size must be power of two");
    for(size_t i=1,j=0;i<n;i++){
        size_t bit=n>>1;
        for(;j&bit;bit>>=1)j^=bit;
        j^=bit;
        if(i<j) std::swap(a[i],a[j]);
    }
    for(size_t len=2;len<=n;len<<=1){
        double angle=(inverse?2:-2)*PI/len;
        Complex delta(std::cos(angle),std::sin(angle));
        for(size_t i=0;i<n;i+=len){
            Complex w(1,0);
            for(size_t j=0;j<len/2;j++){
                auto u=a[i+j],v=a[i+j+len/2]*w;
                a[i+j]=u+v;a[i+j+len/2]=u-v;w*=delta;
            }
        }
    }
    if(inverse)for(auto& x:a)x/=static_cast<double>(n);
}
inline double clamp(double value,double low,double high){return std::max(low,std::min(value,high));}
inline double eqAt(double hz,const Settings& cfg){
    if(hz<1)return 0;
    const auto pos=std::log2(hz/31.25);
    double db=0;
    for(int i=0;i<10;i++){
        const auto oct=(pos-i)/0.55;
        db+=clamp(cfg.gains[i],-24,24)*std::exp(-0.5*oct*oct);
    }
    return clamp(db,-36,36);
}
}
std::vector<float> process(const float* input,size_t count,int sr,const Settings& cfg){
    if(!input||count==0)return {};
    if(sr<8000||sr>192000||count>static_cast<size_t>(sr)*180)throw std::invalid_argument("Invalid audio bounds");
    std::vector<float> output(count,0.0f);
    std::vector<float> accum(N,0.f),norms(N,0.f);
    std::vector<double> window(N);
    std::vector<Complex> bins(N);
    std::vector<double> floor(N/2+1,0.0);
    for(int i=0;i<N;i++)window[i]=0.5-0.5*std::cos(2*PI*i/(N-1));
    // Conservative noise estimate from the beginning of the recording. The
    // interval is not assumed or presented to be definitely noise-only.
    const size_t probeFrames=std::min<size_t>(12,std::max<size_t>(1,(count>N?(count-N)/HOP:1)));
    for(size_t frame=0;frame<probeFrames;frame++){
        size_t start=frame*HOP;
        for(int i=0;i<N;i++){
            size_t ix=start+i;
            bins[i]=Complex(ix<count ? static_cast<double>(input[ix])*window[i] : 0.0,0.0);
        }
        fft(bins,false);
        for(int i=0;i<=N/2;i++)floor[i]+=std::abs(bins[i]);
    }
    for(auto& x:floor)x/=probeFrames;
    for(size_t start=0;start<count;start+=HOP){
        for(int i=0;i<N;i++){
            size_t ix=start+i;
            bins[i]=Complex(ix<count ? static_cast<double>(input[ix])*window[i] : 0.0,0.0);
        }
        fft(bins,false);
        for(int k=0;k<=N/2;k++){
            double hz=static_cast<double>(k)*sr/N;
            double mask=1.0;
            if(cfg.bandFocus){
                double halfWidth=std::max(120.0,static_cast<double>(cfg.widthHz)/2.0);
                double dist=std::abs(hz-cfg.centerHz);
                double edge=0.1*halfWidth+100;
                double outside=clamp((dist-(halfWidth-edge))/(2*edge),0,1);
                outside=outside*outside*(3-2*outside);
                mask=1.0-0.95*clamp(cfg.strength,0,1)*outside;
            }
            double mag=std::abs(bins[k]);
            double ratio=mag/(floor[k]+1e-6);
            double gate=1.0-clamp(cfg.denoise,0,1)*0.83*clamp((2.5-ratio)/2.5,0,1);
            double factor=mask*gate*std::pow(10,eqAt(hz,cfg)/20.0);
            bins[k]*=factor;
            if(k>0&&k<N/2)bins[N-k]*=factor;
        }
        fft(bins,true);
        for(int i=0;i<N && start+static_cast<size_t>(i)<count;i++){
            size_t slot=(start+i)&(N-1);
            double w=window[i];
            accum[slot]+=static_cast<float>(bins[i].real()*w);
            norms[slot]+=static_cast<float>(w*w);
        }
        for(size_t i=start;i<std::min(count,start+HOP);i++){
            size_t slot=i&(N-1);
            output[i]=norms[slot]>1e-6f?accum[slot]/norms[slot]:0;
            accum[slot]=norms[slot]=0;
        }
    }
    double peak=0,power=0;
    for(auto x:output){peak=std::max(peak,static_cast<double>(std::abs(x)));power+=x*x;}
    const double rms=std::sqrt(power/output.size());
    double gain=1.0;
    if(cfg.autoGain&&rms>1e-7)gain=std::min(3.0,0.1259/rms);
    if(peak*gain>0.94)gain=0.94/std::max(peak,1e-8);
    for(auto& x:output)x=static_cast<float>(clamp(x*gain,-1,1));
    return output;
}
std::vector<float> spectrum(const float* input,size_t count,int sr,int n){
    if(!input||count==0||n<2||((n&(n-1))!=0)||n>32768||sr<=0)return {};
    std::vector<Complex> bins(n,Complex(0,0));
    size_t start=count>static_cast<size_t>(n)?count-n:0;
    for(int i=0;i<n && start+static_cast<size_t>(i)<count;i++){
        double w=0.5-0.5*std::cos(2*PI*i/(n-1));
        bins[i]=Complex(input[start+i]*w,0);
    }
    fft(bins,false);
    std::vector<float> magnitudes(n/2+1);
    for(int i=0;i<=n/2;i++)magnitudes[i]=static_cast<float>(20*std::log10(std::max(std::abs(bins[i])/n,1e-7)));
    return magnitudes;
}
}
