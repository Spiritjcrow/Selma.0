// PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.
#pragma once
#include <vector>
#include <cstdint>

namespace audiomatrix {
struct Settings {
  float centerHz=2300.0f;
  float widthHz=3200.0f;
  float strength=0.8f;
  float denoise=0.35f;
  float gains[10]={};
  bool autoGain=true;
  bool bandFocus=true;
};

// Mono offline STFT processor, safe to call from a background worker thread.
// Does not identify speakers; no trained inference model is bundled.
std::vector<float> process(const float* input, size_t count, int sampleRate, const Settings& cfg);
std::vector<float> spectrum(const float* input, size_t count, int sampleRate, int fftSize=1024);
}
