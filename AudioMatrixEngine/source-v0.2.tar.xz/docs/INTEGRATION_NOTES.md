# SelmaOS AudioMatrixEngine handoff: integration decisions

**Proprietary notice:** Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.

## Assembled vs. handoff design

This repository is a **running-platform implementation candidate** rather than a claim that every component mentioned by DeepSeek/Gemini is functional.

* **App entry point:** Java `MainActivity` rather than pasted `AudioMatrixActivity.kt` because the existing, working Android app already includes microphone permissions, import/export, player, and MIDI device management without Jetpack or OAuth dependencies.
* **Ten-band EQ:** Added touch-enabled `EQBandView.java` based on the functional intent of `EQBandView.kt`, log-octave shaping in both Java and native C++ DSP (31.25 Hz through 16 kHz, +/-24 dB bands). This is an STFT spectral equalizer, not yet a classic ten independent biquad parametric filter implementation with adjustable Q.
* **Native C++:** `AudioDsp.cpp` and `NativeBridge.cpp` provide an Android NDK native processing path. Enable with "Native C++ DSP (experimental)". Failed JNI calls fall back to local Java processing. Both pipelines implement spectral focus, conservative denoising, EQ, RMS auto gain, clip protection; both pass host DSP tests.
* **Audio capture and playback:** Android `AudioRecord` and `AudioTrack` are used in this alpha. **Oboe exclusive-mode callback pipeline is not enabled**; the app deliberately enhances offline, not through speaker-monitoring loops. No misleading low-latency real-time microphone-to-speaker guarantee is made.
* **FFT:** Java in-place radix-2 FFT and native `std::complex` FFT are used. **KissFFT is not required or bundled**; loading unnecessary external libraries just to duplicate working code is avoided.
* **Neural separation:** No `separator_model.tflite` artifact or trained model license/contract was actually supplied. It would be deceptive to claim that a generic converted Spleeter SavedModel can automatically match the arbitrary spectrum layout of pasted `NeuralSeparator.cpp`. Model-dependent speaker separation is **disabled, not simulated**. Frequency filtering can alter speech and cannot isolate a chosen individual when voices overlap.
* **Cloud:** The supplied `CloudSyncManager.cpp` uses libcurl on the calling thread despite `uploadAsync` naming. It also lacks HTTP status handling, filename metadata, refresh token support, retries, and file ID mapping. Its bearer-token implementation is not used. Instead, "Save to Drive" delegates to Android's Storage Access Framework, allowing explicit, account-controlled export with no access token placed in native memory. **Background automatic sync is not implemented**.
* **MIDI:** Android framework `MidiManager` maps incoming device controller events (CC74/71/7) to focus parameters. This is not native AMidi. MIDI devices remain optional.
* **WAV:** Source `FileEncoder.cpp` writes IEEE float WAV; the app instead writes broadly compatible 16-bit PCM WAV using `WavCodec`. This does not preserve 32-bit original sample precision, so retain original sources.
* **Spectrum:** Offline spectrum plot and waterfall are implemented. No speaker diarization or independent live tracks.

## Dependency expectations

Android Studio with Java 17, Gradle 8.7, Android SDK 35, NDK `25.2.9519653` (r25c), and CMake 3.22.1. minSdk 26 / targetSdk 34. Github Actions workflow installs NDK and CMake. Local C++ host compilation does not prove an Android NDK APK build.

## Outstanding work

1. Run CI Gradle compile and Android hardware smoke tests before treating app as installable.
2. Test the optional native build on arm64-v8a, x86_64 and at least one 2–4GB memory phone; measure processing duration and energy.
3. Add explicit noise-only region selection, presets with versioned provenance and compare-to-original controls.
4. Add model-driven separation only after valid model weights, tensor shapes, preprocessing, inference runtime and license are supplied and tested.
5. Add optional OAuth Drive automation with account-controlled consent, token storage, HTTP error checks, retry policy and safe background scheduling.
6. Tune audio callback design with Oboe only when low-latency live monitoring is actually requested and validated against feedback risk.
