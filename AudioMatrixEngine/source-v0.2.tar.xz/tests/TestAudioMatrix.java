import sol.selma.audiomatrix.*;
import java.io.*;
public class TestAudioMatrix {
 public static void main(String[] args) throws Exception {
  int rate=44100, n=rate*2;
  float[] data=new float[n];
  for(int i=0;i<n;i++) data[i]=(float)(0.20*Math.sin(2*Math.PI*1000*i/rate)+0.09*Math.sin(2*Math.PI*100*i/rate));
  AudioProcessor.Settings s=new AudioProcessor.Settings();
  s.centerHz=1000;s.widthHz=650;s.filterStrength=.94f;s.noiseReduction=0;s.autoGain=false;
  float[] clean=AudioProcessor.process(data,rate,s,p->{});
  if(clean.length!=data.length)throw new Exception("length changed");
  for(float v:clean) if(!Float.isFinite(v)||Math.abs(v)>1) throw new Exception("invalid samples");
  double amp100=0,amp1000=0,origAmp100=0;
  for(int i=0;i<n;i++){
   amp100+=clean[i]*Math.sin(2*Math.PI*100*i/rate);
   amp1000+=clean[i]*Math.sin(2*Math.PI*1000*i/rate);
   origAmp100+=data[i]*Math.sin(2*Math.PI*100*i/rate);
  }
  System.out.printf("100Hz attenuation factor: %.3f | 1000Hz factor: %.3f%n",amp100/origAmp100,amp1000/(n*.1));
  if(amp100/origAmp100>=0.30)throw new Exception("band filter not functioning");
  if(amp1000/(n*.1)<0.9)throw new Exception("speech target suppressed");
  ByteArrayOutputStream output=new ByteArrayOutputStream(); WavCodec.write(output,clean,rate);
  WavCodec.Audio wav=WavCodec.read(new ByteArrayInputStream(output.toByteArray()));
  if(wav.rate!=rate||wav.samples.length!=n)throw new Exception("WAV roundtrip mismatch");
  AudioProcessor.Settings e=new AudioProcessor.Settings();
  e.bandFocus=false; e.noiseReduction=0; e.autoGain=false; e.bandDb[5]=12;
  float[] eq=AudioProcessor.process(data,rate,e,null);
  double boosted=0;
  for(int i=0;i<n;i++) boosted+=eq[i]*Math.sin(2*Math.PI*1000*i/rate);
  if(boosted<amp1000*1.5)throw new Exception("10-band equalizer failed to boost 1kHz");
  System.out.println("WAV output size: "+output.size()+" bytes. EQ and DSP tests passed.");
 }
}
