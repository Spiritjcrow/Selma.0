#include "../app/src/main/cpp/AudioDsp.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>
int main(){
  const int sr=44100,n=sr;
  std::vector<float> input(n);
  for(int i=0;i<n;i++)input[i]=static_cast<float>(0.2*sin(2*3.141592653589793*1000*i/sr)+0.09*sin(2*3.141592653589793*100*i/sr));
  audiomatrix::Settings s; s.centerHz=1000;s.widthHz=650;s.strength=.94f;s.denoise=0;s.autoGain=false;
  auto out=audiomatrix::process(input.data(),input.size(),sr,s);
  if(out.size()!=input.size())throw std::runtime_error("length mismatch");
  double amp100=0,amp1k=0,original100=0;
  for(int i=0;i<n;i++){
    if(!std::isfinite(out[i])||std::abs(out[i])>1.001f)throw std::runtime_error("sample invalid");
    amp100+=out[i]*sin(2*3.141592653589793*100*i/sr);
    original100+=input[i]*sin(2*3.141592653589793*100*i/sr);
    amp1k+=out[i]*sin(2*3.141592653589793*1000*i/sr);
  }
  std::cout<<"Native attenuation 100Hz="<<(amp100/original100)<<", 1000Hz="<<(amp1k/(n*.1))<<"\n";
  if(amp100/original100>0.3||amp1k/(n*.1)<.85)throw std::runtime_error("focus DSP failed");
  auto base=out;
  s.bandFocus=false;s.gains[5]=12; // 1 kHz log-peaking EQ
  auto boosted=audiomatrix::process(input.data(),input.size(),sr,s);
  double b=0;for(int i=0;i<n;i++)b+=boosted[i]*sin(2*3.141592653589793*1000*i/sr);
  if(b<amp1k*1.5)throw std::runtime_error("EQ boost failed");
  auto magnitudes=audiomatrix::spectrum(input.data(),input.size(),sr);
  if(magnitudes.size()!=513)throw std::runtime_error("spectrum bins failed");
  std::cout<<"Native DSP test passed.\n";
}
