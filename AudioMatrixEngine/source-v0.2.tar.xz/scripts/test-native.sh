#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/audiomatrix-tests
c++ -std=c++17 -O2 -Wall -Wextra -pedantic app/src/main/cpp/AudioDsp.cpp tests/TestNativeDsp.cpp -o /tmp/audiomatrix-tests/test-native
/tmp/audiomatrix-tests/test-native
