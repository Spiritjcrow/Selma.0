#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BUILD_DIR="$(mktemp -d)"
trap 'rm -rf "$BUILD_DIR"' EXIT
javac -d "$BUILD_DIR" app/src/main/java/sol/selma/audiomatrix/{AudioProcessor,WavCodec}.java tests/TestAudioMatrix.java
java -cp "$BUILD_DIR" TestAudioMatrix
