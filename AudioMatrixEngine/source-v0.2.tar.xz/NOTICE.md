PROPRIETARY & CONFIDENTIAL
Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.

This project is supplied for private development and evaluation by its owner.
No redistribution or sublicense is granted by this notice. Third-party
software, including Oboe, KissFFT, and TensorFlow Lite when installed by a
builder, remains subject to its respective upstream license.

The app is experimental audio signal-processing software, not a verified
speaker identification or evidence attribution system. Preserve original
audio when creating filtered copies. There are no third-party native libraries
or trained neural model weights bundled in this distribution.
