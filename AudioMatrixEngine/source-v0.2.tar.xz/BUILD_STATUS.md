# AudioMatrixEngine v0.2.0-alpha | Test and build record

PROPRIETARY & CONFIDENTIAL
Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.

## Verified in this workspace

- Java 21 standalone `scripts/test-dsp.sh`: PASS. 100 Hz attenuation factor 0.107 when 1000 Hz selected, 1000 Hz ratio 1.000; WAV round-trip correct; 10-band EQ response validated.
- Host C++17 `scripts/test-native.sh`: PASS. 100 Hz attenuation factor 0.106691, 1000 Hz ratio 0.999424; 1 kHz EQ boost and 513-bin FFT validated.
- Host JNI shared library compilation with JDK 21 headers: PASS (toolchain only, not Android).
- `AndroidManifest.xml` declares launcher activity, home-screen icon and request-time microphone access.

## Not verified yet

- Android Gradle / SDK build of `app-debug.apk` (Android SDK unavailable here)
- Android NDK cross-compilation, on-device install and actual microphone routing
- Google Drive provider availability on the phone, attached MIDI controller hardware
- Genuine isolated speaker separation or neural model inference (no trained model bundled)

## Build from this package (GitHub Actions)

Copy directory contents into a GitHub repository's root, including `.github/workflows/android-apk.yml`, then go to Actions > Build Android APK > Run workflow. Download the `AudioMatrixEngine-debug-APK` artifact after a successful run and install `app-debug.apk` on Android.

Generated debug APK is for development only. Proper release signing and actual device verification are required for distribution.
