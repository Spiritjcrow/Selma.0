# Audio Matrix · Selma Labs

**PROPRIETARY & CONFIDENTIAL. Copyright © 2026 Joshua John Jackson (ṚədCr○w). All rights reserved.**

A native, **offline-first Android audio workstation** designed for a home-screen app icon. No Termux dependency. Built with the Android SDK, Java 17, and an optional C++17/JNI path, minimum Android 8 (API 26), target API 34.

> **Status: buildable alpha source (v0.2.0-alpha).** Java DSP, WAV encode/decode and native C++ DSP were tested locally with Java 21 and a host C++17 compiler. An Android APK has **not** been compiled or device-tested in this environment because Android SDK / Gradle are not installed here. Use the included GitHub Actions workflow or Android Studio to produce an APK.

## What is implemented

- Native Android launcher icon (adaptive icon for Android 8+).
- Microphone capture in mono PCM 48 kHz (44.1 kHz fallback), up to 120 seconds. Microphone permission is requested only when recording.
- Import common **uncompressed WAV** files (PCM 8/16/24/32-bit or floating-point 32-bit, mono/stereo). Stereo is downmixed to mono. 3-minute decoded duration cap and 70 MB source cap.
- FFT spectrum with adjustable frequency region, spectral waterfall/history, waveform overview and tap-to-target selection.
- STFT overlap-add frequency selection, noise floor suppression, interactive **10-band logarithmic EQ** (31.25 Hz through 16 kHz), optional automatic RMS targeting/peak protection.
- Optional **native C++ offline DSP** engine through NDK/JNI, with automatic Java fallback. No neural model required to run.
- Preview original/enhanced audio through the phone's speaker/headphones.
- Export processed 16-bit mono PCM WAV to a location selected through Android's document picker. The original source remains unmodified.
- **Google Drive export:** choose Google Drive as the save destination in the Android system picker, where available. The button does **not** silently upload or automatically synchronize.
- **MIDI option:** open a connected Android MIDI device and map CC74 to center frequency, CC71 to bandwidth, CC7 to strength. Connected devices must support MIDI output ports.
- No network permissions, ads or analytics. No microphone access before user interaction.

## Explicitly NOT implemented in v0.1

- **True individual-speaker separation, diarization or identification.** Frequency-region isolation is not equivalent to extracting a specific person from overlapping voices. A trained, licensed TFLite/ONNX separation model, compatible preprocessing, and extensive device tests are needed. Do not represent enhanced artifacts as verified speech.
- **Automatic ongoing Google Cloud sync.** Requires OAuth consent, an approved Drive integration and failure handling. Manual cloud export works through the system file picker where a Drive provider is installed.
- **Real-time monitoring of enhanced microphone audio.** Recording shows a spectrum. Heavy offline enhancement runs after stopping to avoid latency/feedback. Oboe is planned but **not** linked in this build.
- **Lossless multitrack/stem splitting or FLAC export.** Output is WAV mono PCM16, not separated stems.
- **Continuous background recording.** The recorder is designed for short, foreground sessions and capped for performance.

## Get an Android APK with GitHub Actions

1. Create a GitHub repository and put the **contents of this project directory** at its repository root, including `.github/workflows/android-apk.yml`.
2. Go to **Actions → Build Android APK → Run workflow** (or push to `main`).
3. When the workflow finishes, open its successful run. Under **Artifacts**, download **AudioMatrixEngine-debug-APK**. Extract the ZIP to obtain `app-debug.apk`.
4. Transfer `app-debug.apk` to the Android phone if necessary. Tap the APK to install; Android may ask permission to install apps from your chosen file manager/browser.
5. Look in the app drawer for **Audio Matrix** and add its icon to the home screen.

The *debug* APK is signed automatically with the Android debug key. It is suitable for personal testing, **not** Play Store distribution. Before publishing, create a release signing key, test across target devices, add accessibility and instrumentation tests and pass a privacy review.

### Build with Android Studio

Open this folder as an Android project, allow Android Studio to install SDK 35, and choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

### CLI when SDK and Gradle are installed

```bash
gradle :app:assembleDebug --no-daemon
```

### DSP smoke tests (requires `javac` and `java` only)

```bash
bash scripts/test-dsp.sh
bash scripts/test-native.sh
```

## Key files

| Location | Purpose |
| --- | --- |
| `app/src/main/java/sol/selma/audiomatrix/MainActivity.java` | Touch UI, Android permission + file pickers, processing workflow |
| `AudioProcessor.java` | FFT, spectral focus, soft noise reduction, 10-band EQ, peak limiter |
| `EQBandView.java` | Interactive ten-band EQ |
| `NativeDsp.java` and `app/src/main/cpp/` | Optional JNI native C++ DSP with Java fallback |
| `AudioRecorder.java` | Microphone capture with memory/duration cap |
| `SpectrumView.java` | Spectrum, spectrogram history and mini-waveform |
| `Playback.java` | PCM playback |
| `MidiController.java` | Optional MIDI CC mapping |
| `WavCodec.java` | WAV import/export |
| `app/src/main/res/drawable/app_icon.xml` | Vector home-screen icon |
| `.github/workflows/android-apk.yml` | Automated Android APK build |

## Privacy and evidence integrity

Audio is processed entirely on-device unless you explicitly export it. Filtered audio can contain artifacts and cannot confirm the words, speaker, direction, or origin of faint sounds. **Preserve the original recording** separately and document filter parameters if using outputs for investigative review. Do not amplify uncertain content into a definitive transcript.

## Planned v0.3+ improvements

- Optional on-device trained speech separation with model loading, provenance and battery/performance fallback.
- Noise-only profile selection and timeline region selection.
- Headphone-safe preview with gain warnings and true peak meter.
- Optional signed-in Drive folder sync after user OAuth consent.
- Real-time NDK/Oboe DSP only if latency testing justifies it, keeping Java fallback for compatibility.

## Why the supplied NDK code was revised

The provided JNI/CMake example referenced missing files and external subprojects (`oboe`, `kissfft`, TensorFlow Lite) and hard-coded model paths. Building those snippets unchanged would fail. The default playback/recording uses the self-contained Java API; the **second native C++17/JNI DSP backend now exists**, without Oboe, TFLite, KissFFT, or libcurl dependencies. Those third-party backends and trained AI models remain clearly identified future features. This preserves an installable, testable baseline rather than shipping nonfunctional native stubs.

See [docs/INTEGRATION_NOTES.md](docs/INTEGRATION_NOTES.md) for module-by-module mapping of the handoff and limitations.
